<?php
    if(isset($_GET["error"]))
        echo "Login incorrect";
    else
        echo "Por favor registrese antes de acceder a esta página";
?>