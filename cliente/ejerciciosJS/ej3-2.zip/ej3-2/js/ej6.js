var date = new Date();
document.write(date.getDate());