//Análisis del juego de una máquina tragaperras.

